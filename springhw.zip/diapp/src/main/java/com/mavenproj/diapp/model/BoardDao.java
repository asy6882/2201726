package com.mavenproj.diapp.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

@Repository("BoardDao")
public class BoardDao {
	
	//MySql DB연결 설정(JDBC 이용)
	String id = "root";
	String password = "111111";
	String url = "jdbc:mysql://localhost:3306/springdb?characterEncoding=utf-8";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	
	public Connection getConn() {
		try {
			//드라이버 로딩
			Class.forName("com.mysql.jdbc.Driver");
			//url, id, password 이용하여 디비 서버 연결
			System.out.println("드라이버 로딩 완료");
			return DriverManager.getConnection(url, id, password);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
				
	}
	
	public void closeConn() {
		if(conn != null) {
			try {
				if(!conn.isClosed())
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				conn = null;
			}
		}
		
		if(pstmt != null) {
			try {
				if(!pstmt.isClosed())
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				pstmt = null;
			}
		}
		
		if(rs != null) {
			try {
				if(!rs.isClosed())
					rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				rs = null;
			}
		}
		
		
	}
	
	//insertBoard(BoardDo bdo)
	//BoardDo에 저장된 데이터를 디비에 저장하는 메소드
	public void insertBoard(BoardDo bdo) {
		System.out.println("insertBoard() 시작");
		
		//디비 연결
		conn = getConn();
		//sql 완성
		String sql = "insert into board values(null, ?, ?, ?)";
		try {
			pstmt = conn.prepareStatement(sql);
			//테이블의 컬럼수와 일치해야함
			pstmt.setString(1, bdo.getTitle());
			pstmt.setString(2, bdo.getWriter());
			pstmt.setString(3, bdo.getContent());
			
			//sql 실행
			//insert문의 경우 테이블의 변화가 있기 때문에 
			//executeUpdate() 메소드 사용
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("insertBoard() 처리 완료");
		
	}
	
	//getboardList()
	//board 테이블에 있는 전체 테이블을 읽어와서 arraylist로 반환하는 메소드
	public ArrayList<BoardDo> getBoardList(){
		System.out.println("getBoardList 시작");
		
		ArrayList<BoardDo> bList = new ArrayList<BoardDo>();
		//1.디비 연결
		conn = getConn();
		//2. sql문 완성
		String sql = "select * from board";
		try {
			pstmt = conn.prepareStatement(sql);
			
			//3.sql 실행
			//실행후에 여러개의 데이터가 전달될 수 있기 때문에, rs로 받아서 처
			rs = pstmt.executeQuery();
			while(rs.next()) {
				BoardDo bdo = new BoardDo();
				bdo.setSeq(rs.getInt(1));
				bdo.setTitle(rs.getString(2));
				bdo.setWriter(rs.getString(3));
				bdo.setContent(rs.getString(4));
				
				bList.add(bdo);
			}
			closeConn();
			System.out.println("getBoardList() 처리 완료");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bList;
	}

	//getOneBoard(BoardDo bdo)
	//Board 테이블에서 하나의 데이터를 읽어와서 반환하는 메소드
	public BoardDo getOneBoard(BoardDo bdo) {
		System.out.println("getOneBoard() 처리 시작");
		//리턴변수 선언
		BoardDo board = new BoardDo();
		
		//1. 디비 연결
		conn = getConn();
		
		//2. sql문 완성
		String sql = "select * from board where seq=?";
		try {
			pstmt = conn.prepareStatement(sql);
			
			//getSeq하면 integer로 리턴돼서 setInt
			pstmt.setInt(1, bdo.getSeq());
			
			//3. sql문 실행
			rs = pstmt.executeQuery();
			while(rs.next()) {
				board.setSeq(rs.getInt(1));
				board.setTitle(rs.getString(2));
				board.setWriter(rs.getString(3));
				board.setContent(rs.getString(4));
			}
			
			//4. 연결해제
			closeConn();
			System.out.println("getOneBoard() 처리 완료");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return board;
	}
	
	//updateBoard(BoardDo bdo)
	//bdo로 입력되는 데이터를 이용해서, Board 테이블을 수정하는 메소드
	public void updateBoard(BoardDo bdo) {
		System.out.println("updateBoard() 처리 시작");
		
		//1. 디비 연결
		conn = getConn();
		//2.sql문 완성
		String sql = "update board set title=?, content=? where seq=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bdo.getTitle());
			pstmt.setString(2, bdo.getContent());
			pstmt.setInt(3, bdo.getSeq());
			
			//3. sql문 실행
			pstmt.executeUpdate();
			//4. 연결 해제
			closeConn();
			System.out.println("updateBoard() 처리 완료");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	//deleteBoard()
	//bdo로 입력되는 seq에 해당되는 데이터를 board 테이블에서 삭제하는 메소드
	public void deleteBoard(BoardDo bdo) {
		System.out.println("deleteBoard() 처리 시작");
		
		//1. 디비 연결
		conn = getConn();
		
		//2. sql문 완성
		String sql = "delete from board where seq=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bdo.getSeq());
			
			//3. sql문 실행
			pstmt.executeUpdate();
			
			//4. 디비 연결 해제
			closeConn();
			System.out.println("deleteBoard() 처리 완료");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}


	