package com.mavenproj.diapp.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mavenproj.diapp.model.BoardDao;
import com.mavenproj.diapp.model.BoardDo;

@Service("boardService")
public class BoardServiceImpl implements BoardService {
	@Autowired
	private BoardDao bdao;

	@Override
	public void insertBoard(BoardDo bdo) {
		// TODO Auto-generated method stub
		bdao.insertBoard(bdo);
		
	}

	@Override
	public ArrayList<BoardDo> getBoardList() {
		// TODO Auto-generated method stub
		return bdao.getBoardList();
	}

	@Override
	public BoardDo getOneBoard(BoardDo bdo) {
		// TODO Auto-generated method stub
		return bdao.getOneBoard(bdo);
	}

	@Override
	public void updateBoard(BoardDo dbo) {
		// TODO Auto-generated method stub
		bdao.updateBoard(dbo);
	}

	@Override
	public void deleteBoard(BoardDo dbo) {
		// TODO Auto-generated method stub
		bdao.deleteBoard(dbo);
	}


}
