package com.mavenproj.diapp.service;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mavenproj.diapp.model.BoardDao;
import com.mavenproj.diapp.model.BoardDo;

public class BoardClient {

	public static void main(String[] args) {
		
		// 설정파일(boardSetting.xml) 실행하여
		// 실행된 결과(객체, 부품일 수도 있구용..)를 context가 가리키게 함
		ApplicationContext context = new ClassPathXmlApplicationContext("boardSetting.xml");
		
		BoardService bService = (BoardService) context.getBean("boardService");
		//1. 디비에 데이터 저장
//		BoardDo bdo = new BoardDo();
//		bdo.setTitle("title3");
//		bdo.setWriter("writer3");
//		bdo.setContent("content3");
//		bService.insertBoard(bdo);
		
		//2. 디비에서 전체 데이터 가져와서 출력하기
//		ArrayList<BoardDo> bList = bService.getBoardList();
//		for(BoardDo bdo : bList) {
//			System.out.println("-->" + bdo.toString());
//		}
		
		//3. 디비에서 하나의 데이터를 가져와서 출력
//		BoardDo bdo = new BoardDo();
//		bdo.setSeq(3); //조회를 위한 seq 번호 저장
//		BoardDo board = bService.getOneBoard(bdo);
//		System.out.println(bdo.getSeq() + " : " + board.toString());
		
		
		//4. 디비에서 하나의 데이터를 수정하고 출력
//		BoardDo bdo = new BoardDo();
//		bdo.setSeq(3); //수정을 위한 seq 설정
//		bdo.setTitle("title 수정"); //수정을 위한 title 설정
//		bdo.setContent("content 수정"); //수정을 위한 content 설정
//		bService.updateBoard(bdo); //수정 메소드 호출
		
		//전체 데이터 출력 코드 넣기 getBoardList 이용
//		ArrayList<BoardDo> bList = bService.getBoardList();
//		for(BoardDo bdo : bList) {
//			System.out.println(bdo.toString());
//		}
//		
//		System.out.println("-------------------");
//		
//		
//		//수정된 데이터 출력 -> getOneBoard 이용
//		BoardDo bdo = new BoardDo();
//		bdo.setSeq(3); 
//		BoardDo board = bService.getOneBoard(bdo);
//		System.out.println("수정된 데이터 출력: " + board.toString());
		
		//5. 디비에서 하나의 데이터를 삭제하고 출력
		BoardDo bdo = new BoardDo();
		bdo.setSeq(2);
		bService.deleteBoard(bdo);
		
		
		
	}

}
